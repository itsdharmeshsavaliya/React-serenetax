import React from "react";
import "../Emp_Home.css";

function Footer() {
  return (
    <>
      <footer className="app-footer mx-0 text-center">
        <span>© 2022 - Serentax</span>
      </footer>
    </>
  );
}

export default Footer;
